keepsimple.cms README
